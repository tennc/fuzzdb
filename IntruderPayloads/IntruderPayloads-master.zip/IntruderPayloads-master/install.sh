#!/bin/bash
mkdir Repositories/
cd Repositories
git clone --depth=1 https://github.com/swisskyrepo/PayloadsAllTheThings.git
git clone --depth=1 https://github.com/xmendez/wfuzz.git
git clone --depth=1 https://github.com/fuzzdb-project/fuzzdb.git
git clone --depth=1 https://github.com/minimaxir/big-list-of-naughty-strings.git
git clone --depth=1 https://github.com/foospidy/payloads.git
git clone --depth=1 https://github.com/danielmiessler/RobotsDisallowed.git
git clone --depth=1 https://github.com/danielmiessler/SecLists.git
