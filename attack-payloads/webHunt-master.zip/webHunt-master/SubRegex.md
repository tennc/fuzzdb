### Extract Subdomains with burp + regexp
##### Regexp:
```
(http[s]?:\/\/)?((-)?[\w+\.]){1,20}domain\.com
```
