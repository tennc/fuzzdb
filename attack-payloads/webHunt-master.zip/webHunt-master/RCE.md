### RCE:

##### Payloads:
https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/Command%20Injection/Intruder

##### Regexp | Keywords
Search in response
```
root:|(uid|gid|groups)=\d+|bytes from \b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b|Configuration File \(php\.ini\) Path |vulnerable 10|Trying \b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b|\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b\s+localhost|BROADCAST,MULTICAST|drwxr-xr|Active Internet connections|Syntax error|sh:|Average Speed   Time|dir: cannot access|<script>alert\(1\)</script>|drwxrwxr|GNU/Linux
```
