# Content Discovery:

## Tools:
* [Ffuf](https://github.com/ffuf/ffuf)
* [Dirsearch](https://github.com/maurosoria/dirsearch)

## Wordlists: 
* [RobotsDisallowed](https://github.com/danielmiessler/RobotsDisallowed)
* [SecLists Web Content](https://github.com/danielmiessler/SecLists/tree/master/Discovery/Web-Content)
* [content_discovery_nullenc0de](https://gist.github.com/nullenc0de/96fb9e934fc16415fbda2f83f08b28e7)
* [content_discovery_all](https://gist.github.com/jhaddix/b80ea67d85c13206125806f0828f4d10)
* [commonspeak2](https://github.com/assetnote/commonspeak2-wordlists)
