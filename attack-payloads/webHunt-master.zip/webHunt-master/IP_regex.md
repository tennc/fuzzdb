# IP Regex

grep IP addresses from response

```
\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b
```
