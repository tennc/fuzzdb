# webHunt

Twitter: @[GochaOqradze](https://twitter.com/GochaOqradze)

```
Web app testing for Bug Bounty Hunting with Burp Suite Pro|Community version
```

### Donate me: 
https://www.paypal.me/Okradze


